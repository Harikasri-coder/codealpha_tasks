let posts = [];

function createPost() {
    const content = document.getElementById("postContent").value;
    const imageUpload = document.getElementById("imageUpload");
    const imageFile = imageUpload.files[0];
    const imageUrl = imageFile ? URL.createObjectURL(imageFile) : null;

    if (content || imageUrl) {
        const post = { content, likes: 0, comments: [], imageUrl };
        posts.unshift(post);
        document.getElementById("postContent").value = "";
        imageUpload.value = ""; // Clear the image input
        renderPosts();
    }
}

function likePost(index) {
    posts[index].likes += 1;
    renderPosts();
}

function commentPost(index) {
    const comment = prompt("Enter your comment:");
    if (comment) {
        posts[index].comments.push(comment);
        renderPosts();
    }
}

function followUser() {
    alert("Followed!");
}

function renderPosts() {
    const postsContainer = document.getElementById("posts");
    postsContainer.innerHTML = "";
    posts.forEach((post, index) => {
        let comments = post.comments.map(comment => `<p>${comment}</p>`).join("");
        postsContainer.innerHTML += `
            <div class="post">
                <p>${post.content}</p>
                ${post.imageUrl ? `<img src="${post.imageUrl}" alt="Post Image">` : ""}
                <span class="like" onclick="likePost(${index})">👍 ${post.likes}</span>
                <span class="comment" onclick="commentPost(${index})">💬 Comment</span>
                <span class="follow" onclick="followUser()">➕ Follow</span>
                <div class="comment-box">${comments}</div>
            </div>
        `;
    });
}
